fn main() {
    gst_plugin_version_helper::info();
}
