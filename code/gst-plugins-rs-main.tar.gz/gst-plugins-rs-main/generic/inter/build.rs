// SPDX-License-Identifier: MPL-2.0

fn main() {
    gst_plugin_version_helper::info()
}
